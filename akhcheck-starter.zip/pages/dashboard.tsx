
import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabaseClient'
import Link from 'next/link'

export default function DashboardPage() {
  const [profile, setProfile] = useState<any>(null)
  const [goals, setGoals] = useState<any[]>([])

  useEffect(()=>{
    async function loadUser() {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) {
        window.location.href = '/auth'
        return
      }
      const { data: profiles } = await supabase.from('profiles').select('*').eq('id', user.id).maybeSingle()
      setProfile(profiles || { id: user.id, display_name: 'You' })
      const { data: goals } = await supabase.from('goals').select('*').eq('owner', user.id)
      setGoals(goals || [])
    }
    loadUser()
  }, [])

  async function signOut() {
    await supabase.auth.signOut()
    window.location.href = '/'
  }

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-4xl mx-auto">
        <header className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-semibold">Dashboard</h1>
          <div className="flex gap-3">
            <Link href="/goals"><a className="px-3 py-2 border rounded">Goals</a></Link>
            <button onClick={signOut} className="px-3 py-2 bg-red-500 text-white rounded">Sign out</button>
          </div>
        </header>

        <section className="bg-white p-4 rounded shadow">
          <h2 className="font-medium">Welcome, {profile?.display_name}</h2>
          <p className="text-sm text-slate-600">Quick snapshot of your activity</p>

          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 border rounded">
              <h3 className="font-medium">Goals ({goals.length})</h3>
              <ul className="mt-2 space-y-2">
                {goals.map(g => <li key={g.id} className="text-sm">{g.title} — {g.goal_type}</li>)}
              </ul>
            </div>
            <div className="p-4 border rounded">
              <h3 className="font-medium">Groups / Challenges</h3>
              <p className="text-sm text-slate-600">Create or join groups to add accountability.</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}
