
import Link from 'next/link'

export default function Home() {
  return (
    <main className="min-h-screen flex items-center justify-center p-6">
      <div className="max-w-xl w-full bg-white rounded-xl shadow p-8">
        <h1 className="text-2xl font-semibold mb-4">AkhCheck — Starter</h1>
        <p className="mb-6">Next.js + Tailwind + Supabase scaffold connected to your Supabase project.</p>
        <div className="flex gap-3">
          <Link href="/auth"><a className="px-4 py-2 bg-sky-600 text-white rounded">Get started (Auth)</a></Link>
          <Link href="/dashboard"><a className="px-4 py-2 border border-slate-200 rounded">Dashboard</a></Link>
        </div>
      </div>
    </main>
  )
}
